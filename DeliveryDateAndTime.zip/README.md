# DeliveryDateAndTime
This is a Magento 2 Module for adding delivery date and time field to the Magento 2 checkout field in one page checkout, it is tested on the Magento 2 luma theme.
