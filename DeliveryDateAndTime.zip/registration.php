<?php
/**
 * Copyright © sourabhcoder. All rights reserved.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Sourabh_DeliveryDateAndTime',
    __DIR__
);
