<?php
/**
 * Copyright © sourabhcoder. All rights reserved.
 */
namespace Sourabh\DeliveryDateAndTime\Block\Adminhtml\DeliveryDateAndTime;

/**
 * Class ExpectedDeliveryDateAndTime
 *
 * @package Sourabh\DeliveryDateAndTime\Block\Adminhtml\DeliveryDateAndTime
 */
class ExpectedDeliveryDateAndTime extends \Magento\Sales\Block\Adminhtml\Order\View\Info
{

}
